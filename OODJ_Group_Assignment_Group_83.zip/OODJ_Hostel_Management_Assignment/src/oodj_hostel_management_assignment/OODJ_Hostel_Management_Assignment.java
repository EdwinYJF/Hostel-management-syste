/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */


package oodj_hostel_management_assignment;
import GUI.LoginPage;
/**
 *
 * @author Acer
 */
public class OODJ_Hostel_Management_Assignment {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        LoginPage login = new LoginPage();
        login.setVisible(true);
    }
    
}
