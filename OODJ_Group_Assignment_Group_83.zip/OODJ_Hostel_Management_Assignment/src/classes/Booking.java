/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes;

/**
 *
 * @author Acer
 */
public class Booking {
    private String bookingId;
    private String bookingDate;
    private String bookingTime;
    private String roomNumber;
    private String studentName;
    private String tpNumber;
    private String icNumber;
    private String contactNumber;
    private String gender;
    private String roomType;
    private String stayPeriod;
    private String status;
    private String price;

    public Booking(String line) {
        String[] tokens = line.split(";");
        this.bookingId = tokens[0];
        this.bookingDate = tokens[1];
        this.bookingTime = tokens[2];
        this.roomNumber = tokens[3];
        this.studentName = tokens[4];
        this.tpNumber = tokens[5];
        this.icNumber = tokens[6];
        this.contactNumber = tokens[7];
        this.gender = tokens[8];
        this.roomType = tokens[9];
        this.stayPeriod = tokens[10];
        this.status = tokens[11];
        this.price = tokens[12];
    }

    public String getBookingId() {
        return bookingId;
    }

    public String getBookingDate() {
        return bookingDate;
    }

    public String getBookingTime() {
        return bookingTime;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public String getStudentName() {
        return studentName;
    }

    public String getTpNumber() {
        return tpNumber;
    }
    
    public String getIcNumber(){
        return icNumber;
    }

    public void setBookingId(String bookingId) {
        this.bookingId = bookingId;
    }

    public void setBookingDate(String bookingDate) {
        this.bookingDate = bookingDate;
    }

    public void setBookingTime(String bookingTime) {
        this.bookingTime = bookingTime;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public void setTpNumber(String tpNumber) {
        this.tpNumber = tpNumber;
    }

    public void setIcNumber(String icNumber) {
        this.icNumber = icNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public void setRoomType(String roomType) {
        this.roomType = roomType;
    }

    public void setStayPeriod(String stayPeriod) {
        this.stayPeriod = stayPeriod;
    }

    public void setPrice(String price) {
        this.price = price;
    }
    
    public String getContactNumber() {
        return contactNumber;
    }

    public String getGender() {
        return gender;
    }

    public String getRoomType() {
        return roomType;
    }

    public String getStayPeriod() {
        return stayPeriod;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getPrice() {
        return price;
    }

    @Override
    public String toString() {
        return "Booking{" +
                "bookingId='" + bookingId + '\'' +
                ", bookingDate='" + bookingDate + '\'' +
                ", bookingTime='" + bookingTime + '\'' +
                ", roomNumber='" + roomNumber + '\'' +
                ", studentName='" + studentName + '\'' +
                ", tpNumber='" + tpNumber + '\'' +
                ", icNumber='" + icNumber + '\'' +
                ", contactNumber='" + contactNumber + '\'' +
                ", gender='" + gender + '\'' +
                ", roomType='" + roomType + '\'' +
                ", stayPeriod='" + stayPeriod + '\'' +
                ", status='" + status + '\'' +
                ", price='" + price + '\'' +
                '}';
    }

    public String toFileString() {
        return bookingId + ";" +
                bookingDate + ";" +
                bookingTime + ";" +
                roomNumber + ";" +
                studentName + ";" +
                tpNumber + ";" +
                icNumber + ";" +
                contactNumber + ";" +
                gender + ";" +
                roomType + ";" +
                stayPeriod + ";" +
                status + ";" +
                price;
    }
}