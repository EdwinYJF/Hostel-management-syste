/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes;

/**
 *
 * @author Acer
 */
public class Student extends User{
    
    private String ic_passport;
    private String gender;
    private String DOB; 
    private String address;
    private String nationality; 
    private String phone_num; 
    private String guard_name; 
    private String g_con_num;  
    private String relationship; 

    public Student(String name, String username, String ic_passport, String DOB, String address, String nationality, String phone_num, String password, String gender, String guard_name, String g_con_num, String relationship) {
        super(username, password, name);
        this.ic_passport = ic_passport;
        this.DOB = DOB;
        this.address = address;
        this.nationality = nationality;
        this.phone_num = phone_num;
        this.gender = gender;
        this.guard_name = guard_name;
        this.g_con_num = g_con_num;
        this.relationship = relationship;
    }

    public String getIc_passport() {
        return ic_passport;
    }

    public void setIc_passport(String ic_passport) {
        this.ic_passport = ic_passport;
    }
    
    public String getDOB() {
        return DOB;
    }

    public void setDOB(String DOB) {
        this.DOB = DOB;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getNationality() {
        return nationality;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    public String getPhone_num() {
        return phone_num;
    }

    public void setPhone_num(String phone_num) {
        this.phone_num = phone_num;
    }
    
    public String getGender(){
        return gender;
    }
    
    public void setGender(String gender){
        this.gender = gender;
    }
    

    public String getGuard_name() {
        return guard_name;
    }

    public void setGuard_name(String guard_name) {
        this.guard_name = guard_name;
    }

    public String getG_con_num() {
        return g_con_num;
    }

    public void setG_con_num(String g_con_num) {
        this.g_con_num = g_con_num;
    }

    public String getRelationship() {
        return relationship;
    }

    public void setRelationship(String relationship) {
        this.relationship = relationship;
    }

    @Override
    public String toString() {
        return super.getName() + ":" + super.getUsername() + ":" + ic_passport + ":" + DOB + ":" + address + ":" + nationality + ":" + phone_num + ":" + super.getPassword() + ":" + gender + ":" + guard_name + ":" + g_con_num + ":" + relationship;
    }

    
}
